//import Hello from './components/Hello';
//import Goodbye from './components/Goodbye';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Card from './components/Card';

function App() {
  

  return (
    <>
   

    {/* <Hello name="Frontend SPA Development"/>
    <Goodbye name="everyone"/> */}

    <Navbar/>
    <Header/>
    <Card/>
    </>
  )
}

export default App
