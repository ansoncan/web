import React from 'react';

const Header = () => {  
    return (
        <>
        <h1 class="text-center">Lorem ipsum dolor</h1>
        <div class="w-100"
            style={{
                display: "flex", 
                justifyContent: "center",
                color: "grey"}}>
        <p class="text-center w-25">Lorem ipsum dolor sit amet, 
            consectetur adipiscing elit, 
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Ut enim ad minim veniam, quis nostrud exercitation ullamco 
            laboris nisi ut aliquip ex ea commodo consequat. 
            Duis aute irure dolor in reprehenderit in voluptate velit 
            esse cillum dolore eu fugiat nulla pariatur. 
            Excepteur sint occaecat cupidatat non proident, 
            sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>

        </div>
                <div class="w-100 d-flex justify-content-center align-items-center">
        <form class="d-flex w-25" role="search">
            <input class="form-control me-2" type="search" aria-label="Search" 
            placeholder="&#xf002;"
            style={{ fontFamily: "FontAwesome, Arial", fontStyle: "normal" }}
            
            />
             <button 
                class="btn btn-outline-success" 
                type="submit"
                style={{ 
                    backgroundColor: "black", 
                    color: "white",
                    borderColor: "black"  }}
                >Search</button>
      </form>

      </div>
        
        </>
      )
    
}  
  
export default Header;